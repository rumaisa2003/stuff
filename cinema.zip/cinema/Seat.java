
/**
 * Write a description of class Seat here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Seat
{
    // instance variables - replace the example below with your own
    private int seatNumber;
    private int rowNumber;
    private boolean isBooked;

    /**
     * Constructor for objects of class Seat
     */
    public Seat(int rowNumber, int seatNumber)
    {
        this.rowNumber = rowNumber;
        this.seatNumber = seatNumber;
        isBooked = false;
    }
    
    public boolean isBooked()
    {
        return isBooked;
    }
    
    public int getRowNumber()
    {
        return rowNumber;
    }
    
    public int getSeatNumber()
    {
        return seatNumber;
    }
    
    public int[] getPosition()
    {
        int[] position = {rowNumber, seatNumber};
        return position;
    }
    
    /**
     * @return true if seat successfully booked, false if the seat was already booked (ie
     * the seat cannot be booked)
     */
    public boolean setBooked()
    {
        if (!isBooked)
        {
            isBooked = true;
            return true;
        }
        else 
        {
            return false;
        }
    }
    
    /**
     * @return true if the seat was successfully set to available, false if it was already
     * available (ie no need to set it to available again)
     */
    public boolean setAvailable()
    {
        if (isBooked)
        {
            isBooked = false;
            return true;
        }
        else
        {
            return false;
        }
    }
}
