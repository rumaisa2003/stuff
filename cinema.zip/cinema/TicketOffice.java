import java.util.ArrayList;
/**
 * Write a description of class TicketOffice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TicketOffice
{
    // instance variables - replace the example below with your own
    private ArrayList<Screen> screens;

    /**
     * Constructor for objects of class TicketOffice
     */
    public TicketOffice()
    {
        screens = new ArrayList<>();
    }

    public void addScreen(int screenID, int rows, int columns)
    {
        screens.add(new Screen(screenID, rows, columns));
    }
    
    public Screen findScreen(int screenID)
    {
        for (Screen screen : screens)
        {
            if (screenID == screen.getScreenID())
            {
                return screen;
            }
        }
        return null;
    }
    
    public void newMovie(int screenID, String movieTitle, int movieCost)
    {
        Screen screen = findScreen(screenID);
        if (screen != null)
        {
            screen.newMovie(movieTitle, movieCost);
        }
    }
    
    public void showMovies()
    {
        System.out.println("<<MOVIES>>");
        for (Screen screen : screens)
        {
            screen.printDetails();
        }
    }
    
    public Ticket bookRandomTicket(String movieTitle)
    {
        Screen screen = findScreenWithMovie(movieTitle);
        if (screen != null)
        {
            Ticket ticket = screen.getRandomTicket();
            if (ticket != null)
            {
                System.out.println("Ticket booked");
                ticket.printDetails();
            }
            return ticket;
        }
        return null;
    }
    
    /**
     * @return the first screen found to be showing the given movie title. null if no 
     * such screens found
     */
    private Screen findScreenWithMovie(String movieTitle)
    {
        for (Screen screen : screens)
        {
            if (screen.getMovieTitle().equals(movieTitle))
            {
                return screen;
            }
        }
        return null;
    }
}
