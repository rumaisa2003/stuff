import java.util.Date;
/**
 * Write a description of class Ticket here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ticket
{
    // instance variables - replace the example below with your own
    private int screenID;
    private String movieTitle;
    private int rowNumber;
    private int seatNumber;
    private int cost;
    private Date dateCreated;
    private static int totalTickets;

    /**
     * Constructor for objects of class Ticket
     */
    public Ticket(Screen screen, int rowNumber, int seatNumber)
    {
        totalTickets ++;
        screenID = screen.getScreenID();
        movieTitle = screen.getMovieTitle();
        cost = screen.getMovieCost();
        this.rowNumber = rowNumber;
        this.seatNumber = seatNumber;
        dateCreated = new Date();
    }

    public static int getTotalTickets()
    {
        return totalTickets;
    }
    
    public void printDetails()
    {
        System.out.println("Movie Title: " + movieTitle + " // Screen Number: " + screenID);
        System.out.println("Row " + rowNumber + " Seat " + seatNumber);
        System.out.println("Cost: £" + cost + " // Date: " + dateCreated);
    }
}
