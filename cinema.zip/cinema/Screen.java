import java.util.ArrayList;
import java.util.Random;
/**
 * Write a description of class Screen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Screen
{
    private int screenID;
    private ArrayList<Seat> seats;
    private String movieTitle;
    private int movieCost;
    private int availableSeats;
    private int rows;
    private int columns;
    private Random rnd;
    /**
     * Constructor for objects of class Screen
     */
    public Screen(int screenID, int rows, int columns)
    {
        this.screenID = screenID;
        this.rows = rows;
        this.columns = columns;
        rnd = new Random();
        
        seats = new ArrayList<>();
        for (int i=1; i<=rows; i++) // rows
        {
            for (int j=1; j<=columns; j++) // seats
            {   
                seats.add(new Seat(i,j));
            }
        }
        availableSeats = seats.size();
    }
    
    public int getScreenID()
    {
        return screenID;
    }
    
    public String getMovieTitle()
    {
        return movieTitle;
    }
    
    public int getMovieCost()
    {
        return movieCost;
    }

    public void emptyScreen()
    {
        for (Seat seat : seats)
        {
            seat.setAvailable();
        }
        availableSeats = seats.size();
    }
    
    public boolean book(int rowNum, int seatNum)
    {
        if (rowNum>=1 && rowNum<=rows && seatNum>=1 && seatNum<=columns)
        {
            int i = (rowNum-1)*columns+seatNum-1;
            Seat seat = seats.get(i);
            if (seat.setBooked())
            {
                availableSeats --;
                System.out.println("You have booked: row " + seat.getRowNumber() + " seat " + seat.getSeatNumber());
                return true;
            }
            else
            {
                System.out.println("Seat unavailable");
                return false;
            }
        }
        else
        {
            System.out.println("Enter valid row/seat number");
            return false;
        }
    }
    
    public void setMovieCost(int cost)
    {
        movieCost = cost;
    }
    
    public void setMovieTitle(String title)
    {
        movieTitle = title;
    }
    
    public void newMovie(String title, int cost)
    {
        movieTitle = title;
        movieCost = cost;
        emptyScreen();
    }
    
    public void printDetails()
    {
        System.out.println("***Screen " + screenID + "***");
        System.out.println("Movie: " + movieTitle + " // Cost per ticket: £" + movieCost);
    }
    
    public Ticket getRandomTicket()
    {
        if (availableSeats > 0)
        {
            int row;
            int col;
            while (true)
            {
                row = rnd.nextInt(rows);
                col = rnd.nextInt(columns);
                if (book(row, col))
                {
                    return new Ticket(this, row, col);
                }
            }
        }
        else
        {
            return null;
        }
    }
}
